package com.liferay.arquillian.sample.constants;

/**
 * @author naveen
 */
public class SamplePortletKeys {

	public static final String SAMPLE =
		"com_liferay_arquillian_sample_SamplePortlet";

}